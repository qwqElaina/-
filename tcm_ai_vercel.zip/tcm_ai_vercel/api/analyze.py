from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

TCM_PATTERNS = [
    {"name": "风寒束表", "keywords": ["怕冷", "恶寒", "无汗", "头痛", "鼻塞", "清涕", "咳嗽"], "tongue": ["薄白"], "pulse": ["浮紧"], "treatment": "辛温解表，宣肺散寒", "formula": "桂枝汤 / 荆防败毒散（教学示例）"},
    {"name": "风热犯肺", "keywords": ["发热", "咽痛", "黄痰", "口渴", "咳嗽", "鼻涕黄", "头痛"], "tongue": ["舌红", "薄黄"], "pulse": ["浮数"], "treatment": "疏风清热，宣肺止咳", "formula": "银翘散 / 桑菊饮（教学示例）"},
    {"name": "脾胃虚弱", "keywords": ["乏力", "食欲差", "腹胀", "便溏", "疲倦", "面色少华"], "tongue": ["舌淡", "苔白"], "pulse": ["细弱", "缓"], "treatment": "健脾益气，和胃助运", "formula": "四君子汤 / 参苓白术散（教学示例）"},
    {"name": "肝郁气滞", "keywords": ["情绪差", "胸闷", "胁肋胀痛", "失眠", "焦虑", "叹气"], "tongue": ["舌淡红"], "pulse": ["弦"], "treatment": "疏肝解郁，理气和中", "formula": "逍遥散 / 柴胡疏肝散（教学示例）"},
    {"name": "痰湿内阻", "keywords": ["肥胖", "胸闷", "痰多", "困倦", "恶心", "头昏"], "tongue": ["苔腻"], "pulse": ["滑"], "treatment": "燥湿化痰，理气和中", "formula": "二陈汤（教学示例）"}
]

WESTERN_RULES = [
    {"name": "上呼吸道感染 / 感冒倾向", "keywords": ["发热", "咳嗽", "鼻塞", "流涕", "咽痛", "头痛"], "advice": "建议完善体温监测、血常规，必要时进行流感或其他呼吸道感染鉴别。"},
    {"name": "胃肠功能紊乱 / 消化系统问题倾向", "keywords": ["腹痛", "腹胀", "恶心", "反酸", "便溏", "食欲差"], "advice": "建议评估饮食史、腹部体征，必要时完善胃肠相关检查。"},
    {"name": "情绪应激 / 睡眠问题倾向", "keywords": ["失眠", "焦虑", "情绪差", "胸闷", "心烦"], "advice": "建议结合睡眠、压力与情绪状态评估，必要时进行心理量表筛查。"},
    {"name": "代谢异常 / 痰湿体质风险倾向", "keywords": ["肥胖", "困倦", "胸闷", "头昏"], "advice": "建议关注 BMI、血脂、血糖、血压等代谢指标。"}
]

def count_matches(text, items):
    return sum(1 for item in items if item and item in text)

def analyze_tcm(symptoms, tongue, pulse):
    scores = []
    full_text = f"{symptoms} {tongue} {pulse}"
    for pattern in TCM_PATTERNS:
        score = count_matches(full_text, pattern["keywords"]) * 2
        score += count_matches(tongue, pattern["tongue"]) * 2
        score += count_matches(pulse, pattern["pulse"]) * 2
        scores.append((score, pattern))
    scores.sort(key=lambda x: x[0], reverse=True)
    best_score, best_pattern = scores[0]
    if best_score <= 0:
        return {"pattern": "暂未识别明确证型", "reason": "当前输入特征不足，建议补充更完整的四诊信息。", "treatment": "建议完善症状、舌象、脉象后再分析。", "formula": "无"}
    matched_keywords = [k for k in best_pattern["keywords"] if k in full_text]
    return {"pattern": best_pattern["name"], "reason": f"匹配到的特征：{'、'.join(matched_keywords) if matched_keywords else '舌脉或症状特征匹配'}", "treatment": best_pattern["treatment"], "formula": best_pattern["formula"]}

def analyze_western(symptoms, history):
    full_text = f"{symptoms} {history}"
    matches = []
    for rule in WESTERN_RULES:
        score = count_matches(full_text, rule["keywords"])
        if score > 0:
            matches.append((score, rule))
    matches.sort(key=lambda x: x[0], reverse=True)
    if not matches:
        return {"direction": "一般内科初步评估", "advice": "建议进一步补充现病史、既往史、生命体征及必要检查。"}
    best = matches[0][1]
    return {"direction": best["name"], "advice": best["advice"]}

def generate_integrated_plan(tcm_result, western_result, age, gender):
    return {
        "summary": f"该案例为{gender}，{age}岁。中医辨证倾向“{tcm_result['pattern']}”，西医方向倾向“{western_result['direction']}”。",
        "tcm_plan": f"中医思路：{tcm_result['treatment']}。教学参考方义：{tcm_result['formula']}。",
        "western_plan": f"西医思路：{western_result['advice']}",
        "integrated_plan": "中西医结合建议：在规范评估基础上，以现代医学完成风险识别与基础检查，以中医辨证进行个体化调理与症状管理。",
        "warning": "本结果仅用于教学演示与项目原型，不作为真实医疗诊断或处方依据。"
    }

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(silent=True) or {}
    age = str(data.get("age", "")).strip()
    gender = str(data.get("gender", "")).strip()
    symptoms = str(data.get("symptoms", "")).strip()
    tongue = str(data.get("tongue", "")).strip()
    pulse = str(data.get("pulse", "")).strip()
    history = str(data.get("history", "")).strip()
    if not symptoms:
        return jsonify({"error": "请至少输入主要症状"}), 400
    tcm_result = analyze_tcm(symptoms, tongue, pulse)
    western_result = analyze_western(symptoms, history)
    integrated = generate_integrated_plan(tcm_result, western_result, age or "未知", gender or "未知")
    return jsonify({"tcm": tcm_result, "western": western_result, "integrated": integrated})

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"ok": True, "message": "tcm-ai-api is running"})

if __name__ == "__main__":
    app.run(debug=True)
