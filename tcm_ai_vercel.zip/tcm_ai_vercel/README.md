# 中西医结合 AI 病例分析平台

可直接上传 GitHub 并部署到 Vercel。

## 运行
pip install -r requirements.txt
flask --app api/analyze.py run

本地访问：
http://127.0.0.1:5000/public/index.html
